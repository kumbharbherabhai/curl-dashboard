import requests
from parsel import Selector
from datetime import datetime
import time
import random
import re
from urllib.parse import urlparse, parse_qs
from proxy_config import get_working_proxy

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 10; SM-A505F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"
]

def extract_pid(url):
    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    return query.get('pid', [None])[0]

def extract_from_js_block(html_text):
    info = {}

    # More relaxed regex using non-greedy matching and allowing extra attributes
    generic = re.search(r'Generic Name<\/div>\s*<span[^>]*?>(.*?)<\/span>', html_text, re.DOTALL)
    origin = re.search(r'Country of Origin<\/div>\s*<span[^>]*?>(.*?)<\/span>', html_text, re.DOTALL)
    manufactured = re.search(r'Manufactured by:<\/div>\s*<ul>\s*<li[^>]*?>(.*?)<\/li>', html_text, re.DOTALL)
    packed = re.search(r'Packed by:<\/div>\s*<ul>\s*<li[^>]*?>(.*?)<\/li>', html_text, re.DOTALL)

    info['generic_name'] = generic.group(1).strip() if generic else None
    info['country_of_origin'] = origin.group(1).strip() if origin else None
    info['manufactured_by'] = manufactured.group(1).strip() if manufactured else None
    info['packed_by'] = packed.group(1).strip() if packed else None

    return info

def scrape_flipkart_product(url):
    try:
        proxy = get_working_proxy()
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.flipkart.com",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
        }

        response = requests.get(url, headers=headers, timeout=25)
        if response.status_code == 429:
            print("⏳ Blocked (429). Retrying with new proxy...")
            time.sleep(5)
            proxy = get_working_proxy()
            response = requests.get(url, headers=headers, proxies=proxy, timeout=25)

        if response.status_code != 200:
            return {"error": f"Status {response.status_code}", "url": url}

        sel = Selector(text=response.text)

        discount = sel.xpath('//div[@class="UkUFwK WW8yVX"]/span/text()').get()
        if not discount:
            discount = sel.xpath('//div[@class="UkUFwK WW8yVX dB67CR"]/span/text()').get()

        image_url = sel.xpath('//div/ul[@class="ZqtVYK"]/li//img/@src').getall()
        if not image_url:
            image_url = sel.xpath('//div[@class="gqcSqV YGE0gZ"]/img[@class="_53J4C- utBuJY"]/@src').get()

        mrp_parts = sel.xpath('//div[@class="yRaY8j A6+E6v"]/text()').getall()
        mrp = "".join(mrp_parts).strip() if mrp_parts else "N/A"

        all_images = sel.xpath('//div[@class="_4WELSP _6lpKCl"]/img[@class="DByuf4 IZexXJ jLEJ7H"]/@src').getall()

        breadcrumb_parts = sel.xpath('//div[@class="cPHDOP"]//div//a//text()').getall()
        category_hierarchy = " > ".join([b.strip() for b in breadcrumb_parts if b.strip()])

        match_variation = re.search(r'"variationId":"(.*?)"', response.text)
        variation_id = match_variation.group(1) if match_variation else "N/A"

        variation_lids = []
        variation_links = sel.xpath('//li[@class="aJWdJI dpZEpc"]/a[@class="CDDksN zmLe5G oZZD+x"]/@href').getall()
        for link in variation_links:
            parsed = urlparse(link)
            query = parse_qs(parsed.query)
            lid = query.get('lid', [None])[0]
            if lid:
                variation_lids.append(lid)

        extra_info = extract_from_js_block(response.text)

        data = {
            "product_url": url,
            "pid": extract_pid(url),
            "source": "flipkart",
            "scraped_date": datetime.now().isoformat(),

            "product_name": sel.xpath('//span[@class="VU-ZEz"]/text()').get(),
            "product_price": sel.xpath('//div[@class="Nx9bqj CxhGGd"]/text()').get(),
            "mrp": mrp,
            "discount": discount,
            "all_image_urls": image_url,
            "main_image_url": image_url[0] if image_url else None,
            "product_review": sel.xpath('//div[@class="XQDdHH uuhqql"]/text()').get(),
            "number_of_ratings": sel.xpath('//span[@class="Wphh3N"]/span/span[contains(text(), "Ratings")]/text()').get(),
            "arrival_date": sel.xpath('//div[@class="hVvnXm"]/span[@class="Y8v7Fl"]/text()').get(),
            "is_sold_out": bool(sel.xpath('//div[@class="Z8JjpR"]')),
            "category_hierarchy": category_hierarchy,
            "variation_id": variation_id,
            "variation_lids": variation_lids,
            "country_code": "IN",
            **extra_info  # Add generic_name, country_of_origin, manufactured_by, packed_by
        }

        return data

    except Exception as e:
        return {"error": str(e), "url": url}