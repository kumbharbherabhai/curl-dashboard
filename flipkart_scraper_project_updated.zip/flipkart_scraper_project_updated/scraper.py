import requests
from parsel import Selector
from datetime import datetime
import re
from urllib.parse import urlparse, parse_qs
# from proxy_config import get_proxy  #  Uses rotating authenticated proxies

# Define common request headers to mimic a real browser
HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
}

# Extract product ID (PID) from Flipkart URL
def extract_pid(url):
    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    return query.get('pid', [None])[0]

# Main function to scrape product data
def scrape_flipkart_product(url):
    try:
        payload = {'api_key': '5c41b5688becd5cc0c19339ba9e7e31d', 'url':url}
        response = requests.get('https://api.scraperapi.com/', params=payload)
        # proxies = get_proxy()  # Enable proxy for anonymity and access
        # response = requests.get(url, headers=HEADERS,
        #                         #proxies=proxies,
        #                         timeout=25)

        if response.status_code != 200:
            return {"error": f"Status {response.status_code}", "url": url}

        sel = Selector(text=response.text)

        # Extract discount
        try:
            discount = sel.xpath('//div[@class="UkUFwK WW8yVX"]/span/text()').get()
            if not discount:
                discount = sel.xpath('//div[@class="UkUFwK WW8yVX dB67CR"]/span/text()').get()
        except:
            discount = None

        # Extract all image URLs (fallback included)
        try:
            image_url = sel.xpath('//div/ul[@class="ZqtVYK"]/li//img/@src').getall()
            if not image_url:
                image_url = [sel.xpath('//div[@class="gqcSqV YGE0gZ"]/img[@class="_53J4C- utBuJY"]/@src').get()]
        except:
            image_url = []
        all_img = ' , '.join(image_url)

        # Extract MRP (e.g. ₹1999)
        try:
            mrp_parts = sel.xpath('//div[@class="yRaY8j A6+E6v"]/text()').getall()
            mrp = "".join(mrp_parts).strip() if mrp_parts else "N/A"
        except:
            mrp = "N/A"

        # Extract additional product images
        try:
            all_images = sel.xpath('//div[@class="_4WELSP _6lpKCl"]/img[@class="DByuf4 IZexXJ jLEJ7H"]/@src').getall()
        except:
            all_images = []

        # Extract breadcrumb/category path
        try:
            breadcrumb_parts = sel.xpath('//div[@class="cPHDOP"]//div//a//text()').getall()
            category_hierarchy = " > ".join([b.strip() for b in breadcrumb_parts if b.strip() and b.strip() != "Home"])
        except:
            category_hierarchy = ""

        # Extract variation ID from embedded JavaScript
        try:
            match_variation = re.search(r'"variationId":"(.*?)"', response.text)
            variation_id = match_variation.group(1) if match_variation else "N/A"
        except:
            variation_id = "N/A"

        # Extract catalog name
        try:
            catalog_name = sel.xpath('//span[@class="VU-ZEz"]/text()').get()
        except:
            catalog_name = None

        # Extract product name
        try:
            product_name = sel.xpath('//span[@class="VU-ZEz"]/text()').get()
        except:
            product_name = None

        # Extract price
        try:
            product_price = sel.xpath('//div[@class="Nx9bqj CxhGGd"]/text()').get()
        except:
            product_price = None

        # Extract review
        try:
            product_review = sel.xpath('//div[@class="XQDdHH uuhqql"]/text()').get()
        except:
            product_review = None

        # Extract total ratings
        try:
            number_of_ratings = sel.xpath('//div[@class="row j-aW8Z"]/div[@class="col-12-12"]/span[contains(text(), "Ratings &")]/text()').get()
        except:
            number_of_ratings = None

        # Extract estimated arrival date
        try:
            arrival_date = sel.xpath('//div[@class="hVvnXm"]/span[@class="Y8v7Fl"]/text()').get()
        except:
            arrival_date = None

        # Check if product is sold out
        try:
            is_sold_out = bool(sel.xpath('//button[@class="QqFHMw vslbG+ _3Yl67G _7Pd1Fp"]/text()').get())
            if is_sold_out:
                is_sold_out="In Stoke"
            else:
                is_sold_out="out of stoke"
        except:
            is_sold_out = "out of stoke"

        # Extract brand name
        try:
            brand = sel.xpath('//h1/span[@class="mEh187"]/text()').get()
            if not brand:
                brand=sel.xpath('//td[contains(text(), "Brand")]//li[@class="HPETK2"]/text()').get()
        except:
            brand = "N/A"

        # Main image
        main_image_url = image_url[0] if image_url else None
        variation_id = match_variation.group(1) if match_variation else "N/A"

        variation_lids = []
        variation_links = sel.xpath('//li[@class="aJWdJI dpZEpc"]/a[@class="CDDksN zmLe5G oZZD+x"]/@href').getall()
        variation_links+= sel.xpath('//li[@class="aJWdJI dpZEpc"]/a[@class="GK7Ljp oZZD+x dpZEpc"]/@href').getall()
        for link in variation_links:
            parsed = urlparse(link)
            query = parse_qs(parsed.query)
            lid = query.get('lid', [None])[0]
            if lid:
                variation_lids.append(lid)

        moq_text = sel.xpath('//li[contains(text(), "Pack of") or contains(text(), "Set of")]/text()').get()

        if not moq_text:
            moq_text = sel.xpath('//div[contains(text(), "Pack of")]/following-sibling::div/text()').get()

        # 3. td + li[@class="HPETK2"]
        if not moq_text:
            moq_text = sel.xpath('//td[text()="Pack of"]/following-sibling::td//li[@class="HPETK2"]/text()').get()

        # Final parse
        if moq_text:
            match = re.search(r'\d+', moq_text)
            moq = int(match.group()) if match else 1
        else:
            moq = 1
        # Format data dictionary
        data = {
            "product_url": url,
            "pid": extract_pid(url),
            "catalog_id": extract_pid(url),
            "source": "flipkart",
            "scraped_date": datetime.now().isoformat(),
            "catalog_name": catalog_name,
            "product_name": product_name,
            "product_price": product_price,
            "product_id":extract_pid(url),
            "mrp": mrp,
            "discount": discount,
            "images": all_img,
            # "all_image_urls": all_img,
            "main_image_url":main_image_url,
            # "image_url": main_image_url,
            "product_review": product_review,
            "brand": brand,
            "number_of_ratings": number_of_ratings,
            "arrival_date": arrival_date,
            "is_sold_out": is_sold_out,
            #"variation_id": variation_id,
            "variation_id": variation_lids,
            "category_hierarchy": category_hierarchy,
            "MOQ":moq,
            "country_code": "IN"

        }

        return data

    except Exception as e:
        return {"error": str(e), "url": url}