# Flipkart Product Scraper (MongoDB + Excel + Proxy)

## 🔧 Requirements
- Python 3.10+
- pip install -r requirements.txt
- MongoDB running on localhost

## 📥 Input
- input.csv with a column 'url'

## 🚀 How to Run
Double-click:
```
run_scraper.bat
```
Or run manually:
```
python main.py
```

## 📤 Output
- MongoDB: flipkart.products collection
- Excel: output.xlsx