import random
import requests

PROXIES = [
    "http://125.18.28.54:8080",
    "http://194.186.248.97:80",
    "http://181.57.131.122:8080",
    "http://46.10.209.230:8080",
    "http://102.222.231.25:2333",
    "http://185.88.154.247:8585",
    "http://188.132.222.41:8080",
    "http://92.67.186.210:80",
    "http://41.59.90.171:80",
    "http://103.162.36.13:8080",
    "https://181.111.164.210:999",
    "http://34.155.66.102:8080",
    "http://102.209.18.28:8080",
    "http://27.76.9.187:10002",
    "http://98.64.128.182:3128",
    "http://108.141.130.146:80",
    "http://103.88.245.234:8080",
    "http://4.195.16.140:80",
    "http://41.249.147.75:39811",
    "http://103.235.174.138:7777",
    "http://4.156.78.45:80",
    "http://185.36.145.215:80",
    "http://37.187.74.125:80",
    "http://43.135.36.240:80",
    "http://203.95.196.96:8080",
    "https://37.27.253.44:8069"
]

def is_proxy_working(proxy_url):
    try:
        response = requests.get("https://httpbin.org/ip", proxies={"http": proxy_url, "https": proxy_url}, timeout=8)
        return response.status_code == 200
    except:
        return False

def get_working_proxy():
    random.shuffle(PROXIES)
    for proxy in PROXIES:
        if is_proxy_working(proxy):
            return {"http": proxy, "https": proxy}
    return None  # No working proxy found
