from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client['flipkarts_01']

product_collection = db['products']
url_collection = db['product_urls']  # For tracking status

def insert_to_mongo(data):
    if isinstance(data, list):
        product_collection.insert_many(data)
    else:
        product_collection.insert_one(data)

def add_pending_urls_from_csv(file_path):
    import pandas as pd
    df = pd.read_csv(file_path)
    urls = df['url'].dropna().unique()
    for url in urls:
        # Insert only if not exists
        if not url_collection.find_one({"url": url}):
            url_collection.insert_one({"url": url, "status": "pending"})

def get_pending_urls():
    return list(url_collection.find({"status": "pending"}))

def mark_url_done(url):
    url_collection.update_one({"url": url}, {"$set": {"status": "done"}})
