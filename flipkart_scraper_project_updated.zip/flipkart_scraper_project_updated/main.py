import os
import time
import random
import pandas as pd
from scraper import scrape_flipkart_product
from db_handler import insert_to_mongo, get_pending_urls, mark_url_done, add_pending_urls_from_csv

EXCEL_FILE = "output.xlsx"
CSV_FILE = "input.csv"

if __name__ == "__main__":
    # STEP 1: Insert URLs to MongoDB (one-time)
    add_pending_urls_from_csv(CSV_FILE)

    # STEP 2: Fetch URLs with "pending" status
    pending_records = get_pending_urls()
    if not pending_records:
        print("✅ No more pending URLs.")
        exit()

    for record in pending_records:
        url = record['url']
        print(f"🔍 Scraping: {url}")

        product_data = scrape_flipkart_product(url)

        if "error" in product_data:
            print(f"❌ Error scraping: {product_data['error']}")
            with open("errors.txt", "a", encoding="utf-8") as f:
                f.write(f"{url} → {product_data['error']}\n")
            continue

        print("✅ Product Scraped:")
        for key, value in product_data.items():
            print(f"{key}: {value}")
        print("=" * 60)

        insert_to_mongo(product_data)

        try:
            if os.path.exists(EXCEL_FILE):
                existing = pd.read_excel(EXCEL_FILE)
                updated = pd.concat([existing, pd.DataFrame([product_data])], ignore_index=True)
            else:
                updated = pd.DataFrame([product_data])
            updated.to_excel(EXCEL_FILE, index=False)
        except Exception as e:
            print(f"❌ Excel Save Error: {e}")

        # ✅ Mark as done
        mark_url_done(url)

        time.sleep(random.uniform(2, 4))

    print("✅ All pending URLs processed.")
