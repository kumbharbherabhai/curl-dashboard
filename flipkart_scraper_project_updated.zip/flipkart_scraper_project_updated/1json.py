import csv
from pymongo import MongoClient

# ✅ MongoDB Connection
client = MongoClient("mongodb://localhost:27017/")
db = client["flipkarts_01"]
collection = db["pending_products"]

# ✅ Input CSV file path
csv_file = "input.csv"

# ✅ Read CSV and insert URLs
with open(csv_file, newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        url = row.get("url", "").strip()
        if url and not collection.find_one({"url": url}):
            collection.insert_one({"url": url, "status": "pending"})
            print(f"✅ Saved: {url}")
        else:
            print(f"⚠️ Already Exists or Empty: {url}")
