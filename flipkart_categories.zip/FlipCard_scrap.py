import requests
from parsel import Selector
import pandas as pd
import json
from bs4 import BeautifulSoup
import sqlite3
import re
import time
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Setup session with retry mechanism
session = requests.Session()
retry = Retry(total=5, backoff_factor=4, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retry)
session.mount("http://", adapter)
session.mount("https://", adapter)

# Headers from your script
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
}

# Initialize SQLite database
conn = sqlite3.connect("flipkart_categories.db")
cursor = conn.cursor()

# Create categorytable
cursor.execute("""
CREATE TABLE IF NOT EXISTS categorytable (
    category_name TEXT,
    category_url TEXT,
    subcategory_name TEXT,
    subcategory_url TEXT,
    sub_subcategory_name TEXT,
    sub_subcategory_url TEXT,
    total_products_available INTEGER
)
""")
conn.commit()

# List of specific categories to scrape
target_categories = [
    "Grocery",
    "Mobiles",
    "Fashion",
    "Electronics",
    "Home & Furniture",
    "Appliances",
    "Flight Bookings",
    "Beauty, Toys & More",
    "Two Wheelers"
]


# Function to extract JSON from page
def extract_json_from_page(url):
    try:
        response = session.get(url, headers=headers, timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")

        # Find script tags containing JSON
        script_tags = soup.find_all("script", {"type": "application/json"}) or soup.find_all("script")
        json_data = None
        for script in script_tags:
            if script.string:
                try:
                    json_data = json.loads(script.string.strip())
                    if any(key in json_data for key in
                           ["categories", "subCategories", "menu", "items", "data", "pageData"]):
                        break
                except json.JSONDecodeError:
                    json_str = re.search(r'(\{.*\})', script.string, re.DOTALL)
                    if json_str:
                        try:
                            json_data = json.loads(json_str.group())
                            break
                        except json.JSONDecodeError:
                            continue
        return json_data
    except requests.RequestException as e:
        print(f"Error extracting JSON from {url}: {e}")
        return None


# Function to extract total products from deepest category page
def get_total_products(url):
    try:
        response = session.get(url, headers=headers, timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")
        selector = Selector(text=response.text)

        # Look for total products in JSON
        json_data = extract_json_from_page(url)
        if json_data:
            for key in ["totalProducts", "productCount", "totalCount", "totalItems", "pageData"]:
                if key in json_data:
                    if key == "pageData" and isinstance(json_data[key], dict):
                        for subkey in ["totalProducts", "productCount", "totalCount", "totalItems"]:
                            if subkey in json_data[key]:
                                return int(json_data[key][subkey]) if isinstance(json_data[key][subkey],
                                                                                 (int, float)) else 0
                    else:
                        return int(json_data[key]) if isinstance(json_data[key], (int, float)) else 0

        # Fallback to HTML (search for text like "Showing 1 – X of Y Products")
        total_text = soup.find(string=re.compile(r'Showing.*of\s*([\d,]+)\s*(Products|Items)', re.I))
        if total_text:
            match = re.search(r'[\d,]+', total_text)
            if match:
                return int(match.group().replace(",", ""))

        # Alternative: XPath for product count
        total_element = selector.xpath(
            '//span[contains(@class, "result-count") or contains(@class, "total-count") or contains(@class, "count") or contains(text(), "Products")]/text()').get()
        if total_element:
            match = re.search(r'[\d,]+', total_element)
            if match:
                return int(match.group().replace(",", ""))

        return 0
    except requests.RequestException as e:
        print(f"Error fetching total products from {url}: {e}")
        return 0


# Function to scrape subcategories recursively
def scrape_category_levels(category_name, category_url, parent_subcategory=None, parent_sub_subcategory=None, depth=0):
    if depth > 2:  # Limit depth to avoid infinite recursion
        return

    try:
        time.sleep(5)  # Delay to avoid rate-limiting
        response = session.get(category_url, headers=headers, timeout=20)
        response.raise_for_status()
        selector = Selector(text=response.text)
        json_data = extract_json_from_page(category_url)
        subcategories = []

        # Parse JSON if available
        if json_data:
            sub_cats = (
                    json_data.get("subCategories", []) or
                    json_data.get("categories", []) or
                    json_data.get("menu", []) or
                    json_data.get("items", []) or
                    json_data.get("data", {}).get("subCategories", []) or
                    json_data.get("data", {}).get("categories", []) or
                    json_data.get("pageData", {}).get("subCategories", []) or
                    json_data.get("pageData", {}).get("categories", [])
            )
            for sub in sub_cats:
                sub_name = sub.get("name", "") or sub.get("title", "") or sub.get("label", "") or sub.get("text", "")
                sub_url = sub.get("url", "") or sub.get("link", "") or sub.get("href", "") or sub.get("destination", "")
                if sub_name and sub_url:
                    if not sub_url.startswith("http"):
                        sub_url = "https://www.flipkart.com" + sub_url
                    subcategories.append({"name": sub_name, "url": sub_url})

        # Fallback to HTML scraping with XPath
        if not subcategories:
            subcategory_blocks = selector.xpath(
                '//a[contains(@class, "sub") or contains(@class, "category") or contains(@class, "menu") or contains(@class, "item") or contains(@class, "link") or contains(@href, "store") or contains(@href, "category")]')
            for block in subcategory_blocks:
                sub_name = block.xpath('.//text()').get(default='').strip()
                sub_url = block.xpath('.//@href').get(default='')
                if sub_name and sub_url and sub_name not in ["", " ", "Home", "All", "Shop Now"]:
                    if not sub_url.startswith("http"):
                        sub_url = "https://www.flipkart.com" + sub_url
                    subcategories.append({"name": sub_name, "url": sub_url})

        # Remove duplicates
        unique_subcategories = []
        seen_urls = set()
        for sub in subcategories:
            if sub["url"] not in seen_urls:
                unique_subcategories.append(sub)
                seen_urls.add(sub["url"])
        subcategories = unique_subcategories

        # Store data and recurse
        for sub in subcategories:
            if depth == 0:  # Subcategory level
                total_products = get_total_products(sub["url"]) if not subcategories else 0
                cursor.execute("""
                    INSERT INTO categorytable (
                        category_name, category_url, subcategory_name, subcategory_url,
                        sub_subcategory_name, sub_subcategory_url, total_products_available
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    category_name, category_url, sub["name"], sub["url"],
                    None, None, total_products
                ))
                conn.commit()
                scrape_category_levels(category_name, sub["url"], sub, None, depth + 1)

            elif depth == 1:  # Sub-subcategory level
                total_products = get_total_products(sub["url"]) if not subcategories else 0
                cursor.execute("""
                    INSERT INTO categorytable (
                        category_name, category_url, subcategory_name, subcategory_url,
                        sub_subcategory_name, sub_subcategory_url, total_products_available
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    category_name, category_url, parent_subcategory["name"], parent_subcategory["url"],
                    sub["name"], sub["url"], total_products
                ))
                conn.commit()
                scrape_category_levels(category_name, sub["url"], parent_subcategory, sub, depth + 1)

            else:  # Deeper levels
                total_products = get_total_products(sub["url"])
                cursor.execute("""
                    INSERT INTO categorytable (
                        category_name, category_url, subcategory_name, subcategory_url,
                        sub_subcategory_name, sub_subcategory_url, total_products_available
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    category_name, category_url, parent_subcategory["name"], parent_subcategory["url"],
                    sub["name"], sub["url"], total_products
                ))
                conn.commit()

        # If no subcategories, store the current level with total products
        if not subcategories:
            total_products = get_total_products(category_url)
            if depth == 0:
                cursor.execute("""
                    INSERT INTO categorytable (
                        category_name, category_url, subcategory_name, subcategory_url,
                        sub_subcategory_name, sub_subcategory_url, total_products_available
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    category_name, category_url, None, None, None, None, total_products
                ))
            elif depth == 1:
                cursor.execute("""
                    INSERT INTO categorytable (
                        category_name, category_url, subcategory_name, subcategory_url,
                        sub_subcategory_name, sub_subcategory_url, total_products_available
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    category_name, category_url, parent_subcategory["name"], parent_subcategory["url"],
                    None, None, total_products
                ))
            conn.commit()

    except requests.RequestException as e:
        print(f"Error scraping {category_name} at {category_url}: {e}")


# Scrape categories from homepage
url = 'https://www.flipkart.com/'
try:
    response = session.get(url, headers=headers, timeout=10)
    response.raise_for_status()
except requests.RequestException as e:
    print(f"Error fetching the page: {e}")
    conn.close()
    exit()

selector = Selector(text=response.text)

# Broader XPath for categories
category_blocks = selector.xpath(
    '//a[contains(@class, "category") or contains(@class, "_3sdu8W") or contains(@class, "J+joAW") or contains(@href, "store") or contains(@href, "category")]')

print(f"\nTotal Categories Found: {len(category_blocks)}\n")

all_category_data = []
for idx, cat in enumerate(category_blocks, start=1):
    name = cat.xpath('.//text()').get(default='').strip()
    link = cat.xpath('.//@href').get(default='')

    # Only process specified categories
    if not name or name not in target_categories:
        continue

    full_link = 'https://www.flipkart.com' + link if link.startswith('/') else link
    print(f"{idx}. {name} --> {full_link}")

    dic = {
        "CategoryName": name,
        "Link": full_link
    }
    print(dic)
    all_category_data.append(dic)

    # Scrape subcategories and store in SQLite
    scrape_category_levels(name, full_link)

# Save to Excel
if all_category_data:
    df = pd.DataFrame(all_category_data)
    df.to_excel("Category_links.xlsx", index=False)
    print("\nData saved to Category_links.xlsx")
else:
    print("\nNo data to save.")

# Print sample data from SQLite for verification
cursor.execute("SELECT * FROM categorytable LIMIT 10")
rows = cursor.fetchall()
print("\nSample data from categorytable:")
for row in rows:
    print(row)
conn.close()