import requests
from parsel import Selector
import json
import re

url = "https://www.flipkart.com/search?q=iphone"
headers = {"User-Agent": "Mozilla/5.0"}

response = requests.get(url, headers=headers)
html = response.text

# ✅ Method 1: XPath se <script type="application/ld+json"> content lo
selector = Selector(text=html)
json_text = selector.xpath('//script[@type="application/ld+json"]/text()').get()

# ✅ Method 2: Agar HTML me koi variable JSON format me embedded ho
# Example: window.__INITIAL_STATE__ = { ... };
match = re.search(r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\});', html, re.DOTALL)
if match:
    json_text = match.group(1)

# ✅ JSON ko parse karo
if json_text:
    try:
        data = json.loads(json_text)
        print("✅ JSON Data Extracted:")
        print(json.dumps(data, indent=2))
    except json.JSONDecodeError as e:
        print("⚠️ JSON decode error:", e)
else:
    print("❌ JSON data not found in HTML.")
