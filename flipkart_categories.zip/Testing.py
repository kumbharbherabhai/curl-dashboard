import requests
from parsel import Selector
import json
import mysql.connector
import re
import uuid
import time
import random
from urllib.parse import urljoin
from typing import List, Dict, Any
from tenacity import retry, stop_after_attempt, wait_exponential
from datetime import datetime

# Configuration
BASE_URL = "https://www.flipkart.com"
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36",
]
MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'root',  # Replace with your MySQL username
    'password': 'actowiz',  # Replace with your MySQL password
    'database': 'flipkart_data',  # Replace with your database name
}


def get_headers() -> Dict[str, str]:
    """Generate random headers with User-Agent."""
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    }


def init_database() -> mysql.connector.connection.MySQLConnection:
    """Initialize MySQL database and create tables."""
    try:
        conn = mysql.connector.connect(**MYSQL_CONFIG)
        cursor = conn.cursor()

        # Drop existing tables to avoid schema conflicts
        cursor.execute('DROP TABLE IF EXISTS product_data')
        cursor.execute('DROP TABLE IF EXISTS categorytable')

        # Create categorytable
        cursor.execute('''
            CREATE TABLE categorytable (
                id VARCHAR(36) PRIMARY KEY,
                category_name TEXT,
                category_url TEXT,
                subcategory_name TEXT,
                subcategory_url TEXT,
                sub_subcategory_name TEXT,
                sub_subcategory_url TEXT,
                total_products_available INT
            )
        ''')

        # Create product_data table
        cursor.execute('''
            CREATE TABLE product_data (
                id VARCHAR(36) PRIMARY KEY,
                product_name TEXT,
                product_url TEXT,
                price FLOAT,
                mrp FLOAT,
                discount TEXT,
                ratings FLOAT,
                reviews_count INT,
                availability_status TEXT,
                brand TEXT,
                image_urls TEXT,
                specifications TEXT,
                seller_info TEXT,
                category_id VARCHAR(36),
                FOREIGN KEY (category_id) REFERENCES categorytable(id)
            )
        ''')

        conn.commit()
        return conn
    except mysql.connector.Error as e:
        raise Exception(f"Failed to initialize MySQL database: {e}")


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def fetch_url(url: str) -> Selector:
    """Fetch URL with retry logic and return parsed Selector."""
    response = requests.get(url, headers=get_headers(), timeout=10)
    response.raise_for_status()
    return Selector(text=response.text)


def get_total_products(selector: Selector, url: str) -> int:
    """Extract total products from a category page."""
    try:
        total_text = selector.xpath("//span[contains(text(), 'Showing')]/text()").get()
        if total_text:
            match = re.search(r'of\s*([\d,]+)\s*results', total_text, re.I)
            if match:
                return int(match.group(1).replace(',', ''))
        return 0
    except Exception as e:
        print(f"Error fetching total products for {url}: {e}")
        return 0


def extract_navigation_json(tree: Selector) -> Dict:
    """Extract RICH_NAVIGATION JSON from script blocks."""
    script_blocks = tree.xpath("//script/text()").getall()
    for block in script_blocks:
        if "RICH_NAVIGATION" in block:
            cleaned = re.sub(r"^.*?({)", r"\1", block.strip())
            cleaned = re.sub(r"(});?\s*$", r"\1", cleaned)
            try:
                return json.loads(cleaned)
            except json.JSONDecodeError as e:
                raise Exception(f"Failed to parse JSON: {e}")
    raise Exception("RICH_NAVIGATION block not found.")


def locate_categories(obj: Any) -> List[Dict]:
    """Recursively locate RICH_NAVIGATION data."""
    if isinstance(obj, dict):
        if obj.get("type") == "RICH_NAVIGATION":
            return obj.get("data", {}).get("renderableComponents", [])
        for v in obj.values():
            result = locate_categories(v)
            if result:
                return result
    elif isinstance(obj, list):
        for item in obj:
            result = locate_categories(item)
            if result:
                return result
    return []


def flatten_categories(nodes: List[Dict], conn: mysql.connector.connection.MySQLConnection,
                       depth: int = 0, lvl1: str = "", lvl2: str = "", parent_id: str = "") -> List[Dict]:
    """Flatten category hierarchy, print, and store in database."""
    cursor = conn.cursor()
    categories = []
    for node in nodes:
        val = node.get("value", {})
        label = val.get("text", "").strip()
        link = urljoin(BASE_URL, node.get("action", {}).get("url", ""))
        sub_items = val.get("items", [])

        # Print category and URL
        indent = "  " * depth
        print(
            f"{indent}{'Main Category' if depth == 0 else 'Subcategory' if depth == 1 else 'Sub-subcategory'}: {label}")
        print(f"{indent}  URL: {link}")
        print(f"{indent}{'=' * 50}")

        # Prepare category entry
        category_id = str(uuid.uuid4())
        entry = {
            "id": category_id,
            "category_name": lvl1 if depth >= 1 else label,
            "category_url": link if depth == 0 else (categories[-1]["category_url"] if categories else ""),
            "subcategory_name": label if depth == 1 else lvl2,
            "subcategory_url": link if depth == 1 else (
                categories[-1]["subcategory_url"] if depth == 2 and categories else ""),
            "sub_subcategory_name": label if depth == 2 else "",
            "sub_subcategory_url": link if depth == 2 else "",
            "total_products_available": 0
        }

        # Determine if this is the deepest level
        is_deepest = not sub_items
        if is_deepest:
            try:
                selector = fetch_url(link)
                entry["total_products_available"] = get_total_products(selector, link)
            except Exception as e:
                print(f"Error fetching category page {link}: {e}")

        # Insert into database
        try:
            cursor.execute('''
                INSERT INTO categorytable (
                    id, category_name, category_url, 
                    subcategory_name, subcategory_url, 
                    sub_subcategory_name, sub_subcategory_url, 
                    total_products_available
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ''', (
                entry["id"],
                entry["category_name"],
                entry["category_url"],
                entry["subcategory_name"],
                entry["subcategory_url"],
                entry["sub_subcategory_name"],
                entry["sub_subcategory_url"],
                entry["total_products_available"]
            ))
            conn.commit()
        except mysql.connector.Error as e:
            print(f"Error inserting category {label}: {e}")

        categories.append(entry)

        # Recursively process sub-items
        if sub_items:
            sub_categories = flatten_categories(sub_items, conn, depth + 1, lvl1 or label,
                                                label if depth == 1 else lvl2, category_id)
            categories.extend(sub_categories)

        time.sleep(random.uniform(0.5, 1.5))

    return categories


def scrape_product_data(category: Dict, conn: mysql.connector.connection.MySQLConnection) -> None:
    """Scrape product details from a category page."""
    cursor = conn.cursor()
    url = category.get("sub_subcategory_url") or category.get("subcategory_url") or category.get("category_url")
    category_id = category["id"]

    try:
        selector = fetch_url(url)
        products = selector.xpath('//div[contains(@class, "_1AtVbE")]//a[contains(@class, "_1fQZEK")]')

        for product in products:
            try:
                product_name = product.xpath('.//div[contains(@class, "_4rR01T")]/text()').get(default="").strip()
                product_url = urljoin(BASE_URL, product.xpath('./@href').get(default=""))
                price_text = product.xpath('.//div[contains(@class, "_30jeq3")]/text()').get(default="").strip()
                mrp_text = product.xpath('.//div[contains(@class, "_3I9_wc")]/text()').get(default="").strip()
                discount = product.xpath('.//div[contains(@class, "_3Ay6Sb")]/span/text()').get(default="").strip()
                ratings = product.xpath('.//div[contains(@class, "_3LWZlK")]/text()').get(default="").strip()
                reviews_text = product.xpath('.//span[contains(@class, "_2_R_DZ")]/text()').get(default="").strip()

                price = float(re.sub(r'[₹,]', '', price_text)) if price_text and re.match(r'₹[\d,]+',
                                                                                          price_text) else 0.0
                mrp = float(re.sub(r'[₹,]', '', mrp_text)) if mrp_text and re.match(r'₹[\d,]+', mrp_text) else price

                reviews_count = 0
                if reviews_text:
                    match = re.search(r'[\d,]+', reviews_text)
                    if match:
                        reviews_count = int(match.group().replace(',', ''))

                product_selector = fetch_url(product_url)

                brand = product_selector.xpath('//span[contains(@class, "B8zL")]/text()').get(default="").strip()
                image_urls = product_selector.xpath('//div[contains(@class, "CXW8mj")]//img/@src').getall()
                image_urls = json.dumps(image_urls[:5])

                specs = {}
                spec_rows = product_selector.xpath('//div[contains(@class, "_1UhVsV")]//tr')
                for row in spec_rows:
                    key = row.xpath('./td[1]/text()').get(default="").strip()
                    value = row.xpath('./td[2]//text()').get(default="").strip()
                    if key and value:
                        specs[key] = value
                specifications = json.dumps(specs)

                seller = product_selector.xpath('//div[@id="sellerName"]//text()').get(default="").strip()
                seller_info = json.dumps({"seller_name": seller}) if seller else "{}"

                availability_status = "In Stock"
                if product_selector.xpath('//div[contains(text(), "Out of Stock")]'):
                    availability_status = "Out of Stock"

                try:
                    cursor.execute('''
                        INSERT INTO product_data (
                            id, product_name, product_url, price, mrp, discount, 
                            ratings, reviews_count, availability_status, brand, 
                            image_urls, specifications, seller_info, category_id
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ''', (
                        str(uuid.uuid4()),
                        product_name,
                        product_url,
                        price,
                        mrp,
                        discount,
                        float(ratings) if ratings else 0.0,
                        reviews_count,
                        availability_status,
                        brand,
                        image_urls,
                        specifications,
                        seller_info,
                        category_id
                    ))
                    conn.commit()
                except mysql.connector.Error as e:
                    print(f"Error inserting product {product_name}: {e}")

                print(f"  Scraped product: {product_name} ({product_url})")

                time.sleep(random.uniform(0.5, 1.5))

            except Exception as e:
                print(f"Error scraping product at {product_url}: {e}")
                continue

    except Exception as e:
        print(f"Error scraping products for category {url}: {e}")


def main():
    """Main function to execute scraping tasks."""
    print(f"🚀 Starting Flipkart scraping at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    try:
        conn = init_database()

        print("📋 Task 1: Scraping Category Hierarchy")
        tree = fetch_url(BASE_URL)
        nav_json = extract_navigation_json(tree)
        nav_data = locate_categories(nav_json)

        print(f"📦 Found {len(nav_data)} root categories")
        print("=" * 50)

        categories = flatten_categories(nav_data, conn)

        print("\n📋 Task 2: Scraping Product Data")
        deepest_categories = [c for c in categories if not c["sub_subcategory_name"] or not c["sub_subcategory_url"]]
        print(f"🔍 Found {len(deepest_categories)} deepest-level categories for product scraping")

        for i, category in enumerate(deepest_categories, 1):
            print(
                f"\n🌐 Scraping products for category {i}/{len(deepest_categories)}: {category.get('sub_subcategory_name') or category.get('subcategory_name') or category.get('category_name')}")
            scrape_product_data(category, conn)

        print(f"🏁 Scraping completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    except Exception as e:
        print(f"❌ Fatal error: {e}")
    finally:
        if 'conn' in locals():
            conn.close()


if __name__ == "__main__":
    main()